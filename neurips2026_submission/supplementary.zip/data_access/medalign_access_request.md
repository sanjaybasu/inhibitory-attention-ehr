# MedAlign Access Request — Research Use Description

**Dataset**: MedAlign (MedAlign Data Set License 1.0)
**Redivis URL**: https://stanford.redivis.com/datasets/48nr-frxd97ewb
**Applicant**: Sanjay Basu, MD PhD
**Institution**: Waymark Care / [Academic affiliation]
**Date**: March 2026

---

## Research Use Description

We are investigating whether inhibitory attention mechanisms in transformer language models
reduce positional bias in long-context clinical EHR processing — specifically the
"lost-in-the-middle" phenomenon, wherein LLMs systematically underperform on information
located in the middle of long input sequences (Liu et al., TACL 2024).

MedAlign's longitudinal clinical records (~78,000 tokens/patient median, 46,252 notes
across 128 note types) and 983 clinician-authored instruction-response pairs provide
the ideal benchmark for this investigation: records are long enough to exhibit
positional degradation, span multiple specialties, and include ground-truth reference
responses that enable rigorous quantitative evaluation.

**Specific aims:**

1. *Characterize lost-in-the-middle in clinical EHR*: Systematically measure how
   retrieval accuracy for clinical facts (medications, diagnoses, lab values) degrades
   as a function of their position within a longitudinal patient record — the first such
   characterization for clinical notes.

2. *Evaluate inhibitory attention mechanisms*: Compare standard transformer attention,
   Differential Transformer (inhibitory attention via dual-softmax subtraction; Hu et al.,
   ICLR 2025), and KV-cache pruning baselines (H2O, SnapKV) on MedAlign instruction
   categories (Retrieve & Summarize, Care Planning, Diagnosis Support).

3. *Propose a query-conditioned clinical suppression layer*: A novel extension of
   Differential Transformer that takes the clinical query as input and gates suppression
   of irrelevant note sections (e.g., suppressing decade-old social history when querying
   current medications). Train the gate on MedAlign instruction pairs; evaluate on
   held-out instructions only.

**Data handling:**
- No model will be fine-tuned on MedAlign data; use is evaluation-only as required by
  the license.
- Data will remain on an encrypted local machine (FileVault-enabled macOS) and
  HIPAA-compliant compute environments only.
- No data will be transmitted to non-HIPAA-compliant APIs (OpenAI, Anthropic, etc.)
  without a signed BAA. All LLM inference will use local models (LLaMA, Mistral) or
  HIPAA-BAA-covered endpoints.
- No redistribution.

**Intended output**: NeurIPS 2026 submission (abstract deadline May 4, 2026).
All published results will use aggregate statistics only; no individual patient
data will appear in any publication.

---

## EHRSHOT Access Request (companion application)

**Dataset**: EHRSHOT (Stanford Credentialed Health Data License)
**Redivis URL**: https://stanford.redivis.com/datasets/53gc-8rhx41kgt

### Research Use Description

We are evaluating whether inhibitory attention mechanisms improve performance on
structured EHR few-shot prediction tasks. EHRSHOT's 15 benchmark tasks (30-day
readmission, lab abnormality prediction, new diagnosis assignment) and the
provided CLMBR-T-base encoder (141M parameters, pretrained on 2.57M patients)
will serve as structured EHR baselines complementing our primary clinical notes
experiments on MedAlign.

Specifically, we will test whether adding a Differential Transformer attention
layer on top of CLMBR-T-base representations improves few-shot accuracy on
EHRSHOT tasks — providing evidence that inhibitory attention generalizes beyond
unstructured text to structured clinical event sequences.

Data handling: Same as MedAlign above. Evaluation-only; no fine-tuning on
EHRSHOT benchmark data; no redistribution; encrypted local storage only.

**Intended output**: Same NeurIPS 2026 submission.

---

## Checklist Before Submitting

- [ ] CITI "Data or Specimens Only Research" certificate uploaded
- [ ] Institutional email used for Redivis account
- [ ] FileVault encryption verified: `System Preferences → Security → FileVault`
- [ ] MedAlign License 1.0 signed via Redivis portal
- [ ] Stanford Credentialed Health Data License signed via Redivis portal
- [ ] Research use description pasted into Redivis application form
- [ ] Encrypted storage attestation checked
