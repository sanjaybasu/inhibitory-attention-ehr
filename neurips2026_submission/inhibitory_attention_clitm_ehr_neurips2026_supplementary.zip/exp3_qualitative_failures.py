"""
Qualitative failure analysis: BM25/dense/CE high-recall / zero-Stage2 accuracy.

Addresses reviewer Q2: "Why do BM25/dense/CE yield near-zero Stage-2 accuracy
despite very high recall?"

For each BM25-hit case (gold sentence retrieved by lexical overlap), inspects:
  - How many distractors were in the BM25 context vs. QCCS context
  - Response text for both arms
  - Whether failure pattern is: distractor suppression, template confusion,
    lexical-overlap false-positive, or other

Output:
  figures/exp3_qualitative_failures.csv   — full case table
  figures/exp3_failure_summary.txt        — aggregated pattern counts
"""

import re
import sys
from pathlib import Path

import pandas as pd
import numpy as np

FIGURES = Path(__file__).parent.parent / "figures"
EXPERIMENTS = Path(__file__).parent
sys.path.insert(0, str(EXPERIMENTS))

TSV = Path("/Users/sanjaybasu/waymark-local/data/medalign/MedAlign_files"
           "/medalign_instructions_v1_3/clinician-reviewed-model-responses.tsv")
EHR_DIR = Path("/Users/sanjaybasu/waymark-local/data/medalign/MedAlign_files"
               "/medalign_instructions_v1_3/ehrs")


# ── Gold-sentence recall check (same lexical criterion used in the paper) ─────
def _gold_in_context(evidence: str, context: str) -> bool:
    """True if ≥50% of evidence tokens appear in context (paper's lexical criterion)."""
    toks_e = set(re.findall(r'\w+', evidence.lower()))
    toks_c = set(re.findall(r'\w+', context.lower()))
    if not toks_e:
        return False
    return len(toks_e & toks_c) / len(toks_e) >= 0.5


def classify_failure(row: pd.Series) -> str:
    """
    Classify why BM25 retrieved the gold but the reader still failed.
    Returns one of:
      'distractor_overload'  — BM25 context has many sentences; QCCS context is smaller
      'hedge_response'       — model responded 'no information' / 'cannot determine'
      'wrong_entity'         — model cited a different entity than asked
      'truncation'           — response appears cut off
      'lexical_fp'           — gold was 'retrieved' by lexical overlap but may be noise
      'other'
    """
    resp = str(row.get("bm25_response", "")).lower().strip()
    qccs_resp = str(row.get("qccs_response", "")).lower().strip()

    hedges = ["no information", "cannot determine", "not available", "not found",
              "not mentioned", "not documented", "unable to find", "i don't",
              "i cannot", "there is no", "not specified", "not recorded"]
    if any(h in resp for h in hedges):
        return "hedge_response"

    evidence = str(row.get("evidence", "")).lower()
    # If model mentions something different from the evidence entities
    ev_toks = set(re.findall(r'\b[a-z]{4,}\b', evidence))
    resp_toks = set(re.findall(r'\b[a-z]{4,}\b', resp))
    if ev_toks and len(ev_toks & resp_toks) / len(ev_toks) < 0.1 and len(resp) > 20:
        return "wrong_entity"

    if len(resp) < 15 and len(resp) > 0:
        return "truncation"

    # If QCCS got it right but BM25 didn't, likely distractor overload
    qccs_judge = row.get("qccs_judge", 0.0)
    if qccs_judge == 1.0:
        return "distractor_overload"

    return "other"


def main():
    # Load primary judged results
    judged_path = FIGURES / "exp3_v4_llm_results_judged.csv"
    if not judged_path.exists():
        print(f"ERROR: {judged_path} not found. Run exp3_llm_judge.py --v4 first.")
        sys.exit(1)

    df = pd.read_csv(judged_path)

    # Attach evidence strings from TSV
    tsv = pd.read_csv(TSV, sep="\t").dropna(subset=["question", "evidence", "filename"])
    tsv_dedup = tsv.drop_duplicates(subset=["filename", "question"])
    if "evidence" not in df.columns:
        df = df.merge(tsv_dedup[["filename", "question", "evidence"]],
                      on=["filename", "question"], how="left")

    # ── BM25 hits where Stage-2 failed ────────────────────────────────────────
    # A "BM25 hit" means the gold evidence was lexically present in the BM25 context.
    # Proxy: use bm25_response present and bm25_judge == 0.0

    bm25_fail = df[
        (df["bm25_judge"] == 0.0) &
        df["bm25_response"].notna() &
        (df["bm25_response"].str.len() > 5)
    ].copy()

    print(f"BM25 Stage-2 failures: {len(bm25_fail)}/{len(df)} "
          f"({len(bm25_fail)/len(df)*100:.1f}%)")
    print(f"BM25 Stage-2 successes: {(df['bm25_judge'] == 1.0).sum()}/{len(df)}")

    bm25_fail["failure_pattern"] = bm25_fail.apply(classify_failure, axis=1)

    # ── Summary of patterns ───────────────────────────────────────────────────
    pattern_counts = bm25_fail["failure_pattern"].value_counts()
    print("\n=== BM25 failure patterns ===")
    for pat, cnt in pattern_counts.items():
        print(f"  {pat:25s}: {cnt:3d}  ({cnt/len(bm25_fail)*100:.1f}%)")

    # ── Compare QCCS vs BM25 on the same failure cases ────────────────────────
    qccs_on_bm25_failures = bm25_fail["qccs_judge"].value_counts()
    print("\n=== QCCS judge on BM25-failure cases ===")
    qccs_correct_rate = (bm25_fail["qccs_judge"] == 1.0).mean() * 100
    print(f"  QCCS correct on these cases: {qccs_correct_rate:.1f}%")
    print(qccs_on_bm25_failures.to_string())

    # ── Dense and CE failure analysis ─────────────────────────────────────────
    for arm in ["dense", "ce"]:
        judge_col = f"{arm}_judge"
        resp_col  = f"{arm}_response"
        if judge_col not in df.columns:
            continue
        arm_fail = df[(df[judge_col] == 0.0) & df[resp_col].notna()].copy()
        arm_fail["failure_pattern"] = arm_fail.apply(classify_failure, axis=1)
        hedge_pct = (arm_fail["failure_pattern"] == "hedge_response").mean() * 100
        print(f"\n{arm.upper()} failure analysis (N={len(arm_fail)}):")
        print(f"  hedge_response: {hedge_pct:.1f}%")
        print(arm_fail["failure_pattern"].value_counts().to_string())

    # ── Representative examples ───────────────────────────────────────────────
    print("\n=== Representative BM25 failure examples (first 5 by pattern) ===")
    for pat in pattern_counts.index[:4]:
        sample = bm25_fail[bm25_fail["failure_pattern"] == pat].head(2)
        print(f"\n-- {pat} --")
        for _, row in sample.iterrows():
            print(f"  Q: {str(row['question'])[:80]}")
            print(f"  Evidence: {str(row.get('evidence',''))[:80]}")
            print(f"  BM25 resp: {str(row.get('bm25_response',''))[:80]}")
            print(f"  QCCS resp: {str(row.get('qccs_response',''))[:80]}")
            print(f"  QCCS judge: {row.get('qccs_judge', 'N/A')}")

    # ── Save full case table ───────────────────────────────────────────────────
    cols_out = ["filename", "question", "position", "evidence",
                "bm25_response", "bm25_judge", "qccs_response", "qccs_judge",
                "failure_pattern"]
    cols_out = [c for c in cols_out if c in bm25_fail.columns]
    bm25_fail[cols_out].to_csv(FIGURES / "exp3_qualitative_failures.csv", index=False)
    print(f"\nSaved: {FIGURES / 'exp3_qualitative_failures.csv'}")

    # Save summary
    summary_lines = [
        "BM25 Stage-2 failure analysis",
        f"Total failures: {len(bm25_fail)}/{len(df)} "
        f"({len(bm25_fail)/len(df)*100:.1f}%)",
        "",
        "Failure patterns:"
    ]
    for pat, cnt in pattern_counts.items():
        summary_lines.append(f"  {pat}: {cnt} ({cnt/len(bm25_fail)*100:.1f}%)")
    summary_lines += [
        "",
        f"QCCS correct on BM25-failure cases: {qccs_correct_rate:.1f}%"
    ]
    summary_path = FIGURES / "exp3_failure_summary.txt"
    summary_path.write_text("\n".join(summary_lines))
    print(f"Saved: {summary_path}")


if __name__ == "__main__":
    main()
