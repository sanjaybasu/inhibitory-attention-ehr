"""
Experiment 1: Lost-in-the-Middle Characterization in Clinical EHR
=================================================================
Measures how LLM retrieval accuracy for clinical facts degrades as a function
of the fact's position within a long patient record.

Produces the core Figure 1 (U-curve) for the paper.

Supports two data sources:
  --source medalign  : MedAlign format (XML EHR + instruction JSON)
  --source waymark   : Waymark encounter notes (CSV, for smoke-testing)

Usage:
  python exp1_litm_characterization.py --source medalign --data_dir /path/to/medalign
  python exp1_litm_characterization.py --source waymark --smoke_test

Requires:
  pip install transformers torch pandas numpy matplotlib tqdm openai
"""

import argparse
import csv
import json
import os
import random
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class ClinicalRecord:
    """A single patient's longitudinal EHR record."""
    patient_id: str
    text: str                        # full concatenated record (plain text)
    tokens_approx: int = 0           # rough word-count proxy
    source: str = ""                 # "medalign" | "waymark"
    metadata: dict = field(default_factory=dict)


@dataclass
class NeedleProbe:
    """A (needle, query, answer) triple for position-injection experiments."""
    needle: str          # clinical fact sentence to inject
    query: str           # question the model must answer
    answer: str          # expected answer string
    domain: str          # "medication" | "diagnosis" | "lab" | "social"


# ---------------------------------------------------------------------------
# Synthetic needle bank (used when ground-truth needles aren't extractable)
# ---------------------------------------------------------------------------

NEEDLE_BANK: list[NeedleProbe] = [
    NeedleProbe(
        needle="Patient's metformin dose was increased to 1000mg twice daily on 2023-03-15.",
        query="What is the patient's current metformin dose?",
        answer="1000mg twice daily",
        domain="medication",
    ),
    NeedleProbe(
        needle="HbA1c result from 2023-01-10 was 8.4%.",
        query="What was the patient's most recent HbA1c value?",
        answer="8.4%",
        domain="lab",
    ),
    NeedleProbe(
        needle="Patient was diagnosed with stage 3 chronic kidney disease on 2022-11-05.",
        query="What stage of chronic kidney disease does the patient have?",
        answer="stage 3",
        domain="diagnosis",
    ),
    NeedleProbe(
        needle="Patient reported experiencing homelessness and staying at a shelter as of 2023-06-01.",
        query="What is the patient's current housing situation?",
        answer="homeless, staying at a shelter",
        domain="social",
    ),
    NeedleProbe(
        needle="Lisinopril 10mg daily was started for hypertension management on 2023-08-22.",
        query="What medication was started for hypertension management?",
        answer="lisinopril 10mg daily",
        domain="medication",
    ),
    NeedleProbe(
        needle="Colonoscopy completed 2022-05-14 showed no polyps; next due 2032.",
        query="When is the patient's next colonoscopy due?",
        answer="2032",
        domain="diagnosis",
    ),
    NeedleProbe(
        needle="Patient's eGFR on 2023-04-02 was 42 mL/min/1.73m².",
        query="What was the patient's most recent eGFR?",
        answer="42",
        domain="lab",
    ),
    NeedleProbe(
        needle="Patient has a documented allergy to penicillin causing anaphylaxis.",
        query="What antibiotic allergy does the patient have?",
        answer="penicillin",
        domain="medication",
    ),
]


# ---------------------------------------------------------------------------
# Data loaders
# ---------------------------------------------------------------------------

def load_waymark_notes(csv_path: str, min_words: int = 200,
                       max_patients: int = 50) -> list[ClinicalRecord]:
    """
    Load Waymark encounter notes, concatenate per patient, return long records.
    Filters to patients with >= min_words total to ensure enough context.
    """
    from collections import defaultdict
    patient_notes: dict[str, list] = defaultdict(list)

    with open(csv_path, encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        for row in reader:
            pid = row.get("WaymarkId", "")
            text = row.get("text", "").strip()
            date = row.get("dateOfEncounter", "")
            etype = row.get("encounterType", "")
            if text and pid:
                patient_notes[pid].append((date, etype, text))

    records = []
    for pid, notes in patient_notes.items():
        # Sort chronologically
        notes.sort(key=lambda x: x[0])
        combined = "\n\n".join(
            f"[{date} | {etype}]\n{text}" for date, etype, text in notes
        )
        words = len(combined.split())
        if words >= min_words:
            records.append(ClinicalRecord(
                patient_id=pid,
                text=combined,
                tokens_approx=words,
                source="waymark",
            ))

    records.sort(key=lambda r: -r.tokens_approx)
    return records[:max_patients]


def load_medalign_records(data_dir: str,
                          max_records: int = 200) -> list[ClinicalRecord]:
    """
    Load MedAlign patient records.
    MedAlign provides EHR as XML serialized to text; instructions as JSON.
    Adapt paths to match actual MedAlign directory layout after download.
    """
    data_path = Path(data_dir)
    records = []

    # MedAlign layout (adjust if different after download):
    #   data_dir/
    #     ehr_records/  *.txt  (serialized EHR per patient)
    #     instructions/ *.json (instruction-response pairs)
    ehr_dir = data_path / "ehr_records"
    if not ehr_dir.exists():
        # Try flat layout
        ehr_dir = data_path

    for p in sorted(ehr_dir.glob("*.txt"))[:max_records]:
        pid = p.stem
        text = p.read_text(encoding="utf-8", errors="replace")
        records.append(ClinicalRecord(
            patient_id=pid,
            text=text,
            tokens_approx=len(text.split()),
            source="medalign",
        ))

    return records


# ---------------------------------------------------------------------------
# Needle injection
# ---------------------------------------------------------------------------

def inject_needle(record: ClinicalRecord, needle: NeedleProbe,
                  position_frac: float) -> str:
    """
    Insert needle sentence at `position_frac` (0.0 = start, 1.0 = end)
    of the record text. Returns the modified text.
    """
    words = record.text.split()
    insert_idx = int(len(words) * position_frac)
    injected = words[:insert_idx] + needle.needle.split() + words[insert_idx:]
    return " ".join(injected)


# ---------------------------------------------------------------------------
# Model inference
# ---------------------------------------------------------------------------

def query_model_local(context: str, question: str,
                      model_name: str = "mistralai/Mistral-7B-Instruct-v0.2",
                      max_new_tokens: int = 64) -> str:
    """
    Run inference with a local HuggingFace model.
    Requires: pip install transformers accelerate bitsandbytes
    """
    from transformers import AutoTokenizer, AutoModelForCausalLM
    import torch

    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(
        model_name, device_map="auto", torch_dtype=torch.float16,
        load_in_4bit=True,
    )

    prompt = (
        f"You are a clinical assistant. Based only on the patient record below, "
        f"answer the question briefly.\n\n"
        f"PATIENT RECORD:\n{context[:12000]}\n\n"  # truncate to model limit
        f"QUESTION: {question}\n\n"
        f"ANSWER:"
    )
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        out = model.generate(**inputs, max_new_tokens=max_new_tokens,
                             do_sample=False)
    response = tokenizer.decode(out[0][inputs["input_ids"].shape[1]:],
                                skip_special_tokens=True)
    return response.strip()


def query_model_api(context: str, question: str,
                    model: str = "gpt-4o",
                    api_key: Optional[str] = None) -> str:
    """
    Run inference via OpenAI-compatible API.
    NOTE: Only use HIPAA-BAA-covered endpoints with PHI data.
    For MedAlign, use local models unless you have a BAA in place.
    """
    import openai
    client = openai.OpenAI(api_key=api_key or os.environ["OPENAI_API_KEY"])
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system",
             "content": "You are a clinical assistant. Answer questions "
                        "based only on the provided patient record. "
                        "Be brief and specific."},
            {"role": "user",
             "content": f"PATIENT RECORD:\n{context}\n\nQUESTION: {question}"},
        ],
        max_tokens=64,
        temperature=0,
    )
    return resp.choices[0].message.content.strip()


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------

def score_response(response: str, expected: str) -> float:
    """
    Simple exact/partial match score.
    Returns 1.0 (exact), 0.5 (partial), or 0.0 (miss).
    """
    resp_lower = response.lower()
    exp_lower = expected.lower()
    if exp_lower in resp_lower:
        return 1.0
    # Partial: any token of expected present
    exp_tokens = set(re.findall(r'\w+', exp_lower))
    resp_tokens = set(re.findall(r'\w+', resp_lower))
    overlap = exp_tokens & resp_tokens
    if overlap and len(overlap) / len(exp_tokens) >= 0.5:
        return 0.5
    return 0.0


# ---------------------------------------------------------------------------
# Main experiment loop
# ---------------------------------------------------------------------------

POSITIONS = [0.05, 0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.95]
POSITION_LABELS = ["5%", "15%", "25%", "35%", "45%", "55%", "65%", "75%", "85%", "95%"]


def run_experiment(records: list[ClinicalRecord],
                   needles: list[NeedleProbe],
                   inference_fn,
                   output_csv: str,
                   n_trials_per_position: int = 5,
                   seed: int = 42) -> pd.DataFrame:
    """
    For each (record, needle, position) triple, inject the needle, query the
    model, score the response. Aggregate accuracy by position decile.

    Returns a DataFrame with columns: position_frac, domain, score, record_id,
    needle_query, model_response.
    """
    random.seed(seed)
    np.random.seed(seed)

    rows = []
    total = len(POSITIONS) * len(needles) * n_trials_per_position
    done = 0

    for pos_frac, pos_label in zip(POSITIONS, POSITION_LABELS):
        for needle in needles:
            trial_records = random.choices(records, k=n_trials_per_position)
            for rec in trial_records:
                context = inject_needle(rec, needle, pos_frac)
                try:
                    response = inference_fn(context, needle.query)
                    score = score_response(response, needle.answer)
                except Exception as e:
                    response = f"ERROR: {e}"
                    score = float("nan")

                rows.append({
                    "position_frac": pos_frac,
                    "position_label": pos_label,
                    "domain": needle.domain,
                    "score": score,
                    "record_id": rec.patient_id,
                    "record_words": rec.tokens_approx,
                    "needle_query": needle.query,
                    "expected_answer": needle.answer,
                    "model_response": response[:200],
                })
                done += 1
                if done % 10 == 0:
                    print(f"  Progress: {done}/{total}")

    df = pd.DataFrame(rows)
    df.to_csv(output_csv, index=False)
    print(f"Results saved to {output_csv}")
    return df


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------

def plot_ucurve(df: pd.DataFrame, output_path: str,
                title: str = "Lost-in-the-Middle: Clinical EHR") -> None:
    """
    Produces Figure 1: retrieval accuracy vs. document position (U-curve).
    Overlays per-domain lines + overall mean.
    """
    import matplotlib.pyplot as plt
    import matplotlib.ticker as mtick

    fig, ax = plt.subplots(figsize=(7, 4.5))

    # Overall mean
    agg = df.groupby("position_frac")["score"].mean().reset_index()
    ax.plot(agg["position_frac"] * 100, agg["score"] * 100,
            color="black", linewidth=2.5, marker="o", markersize=6,
            label="Overall", zorder=5)

    # Per-domain
    colors = {"medication": "#2196F3", "lab": "#4CAF50",
              "diagnosis": "#FF9800", "social": "#9C27B0"}
    for domain, color in colors.items():
        sub = df[df["domain"] == domain].groupby("position_frac")["score"].mean().reset_index()
        if sub.empty:
            continue
        ax.plot(sub["position_frac"] * 100, sub["score"] * 100,
                color=color, linewidth=1.5, marker="s", markersize=4,
                alpha=0.75, linestyle="--", label=domain.capitalize())

    ax.set_xlabel("Position of clinical fact in patient record (%)", fontsize=12)
    ax.set_ylabel("Retrieval accuracy (%)", fontsize=12)
    ax.set_title(title, fontsize=13, fontweight="bold")
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 105)
    ax.yaxis.set_major_formatter(mtick.PercentFormatter())
    ax.xaxis.set_major_formatter(mtick.PercentFormatter())
    ax.legend(fontsize=10, loc="lower center", ncol=3)
    ax.grid(True, alpha=0.3)
    ax.axvspan(20, 80, alpha=0.06, color="gray", label="_Middle zone")

    # Annotate the dip
    mid_acc = df[(df["position_frac"] >= 0.35) & (df["position_frac"] <= 0.65)]["score"].mean()
    edge_acc = df[(df["position_frac"] <= 0.15) | (df["position_frac"] >= 0.85)]["score"].mean()
    if not np.isnan(mid_acc) and not np.isnan(edge_acc):
        ax.annotate(
            f"Middle dip: −{(edge_acc - mid_acc) * 100:.1f}pp",
            xy=(0.5, mid_acc * 100), xycoords=("axes fraction", "data"),
            xytext=(0.5, mid_acc * 100 + 8),
            ha="center", fontsize=9, color="gray",
            arrowprops=dict(arrowstyle="->", color="gray"),
        )

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    print(f"Figure saved to {output_path}")
    plt.close()


def print_summary(df: pd.DataFrame) -> None:
    """Print a concise summary table for the paper."""
    agg = df.groupby("position_label")["score"].agg(["mean", "sem", "count"])
    agg.columns = ["accuracy", "sem", "n"]
    agg["accuracy_pct"] = (agg["accuracy"] * 100).round(1)
    agg["ci95"] = (agg["sem"] * 1.96 * 100).round(1)
    print("\n=== Lost-in-the-Middle Summary ===")
    print(agg[["accuracy_pct", "ci95", "n"]].to_string())

    mid = df[(df["position_frac"] >= 0.35) & (df["position_frac"] <= 0.65)]["score"].mean()
    edge = df[(df["position_frac"] <= 0.15) | (df["position_frac"] >= 0.85)]["score"].mean()
    print(f"\nEdge accuracy (0-15% + 85-100%): {edge*100:.1f}%")
    print(f"Middle accuracy (35-65%):         {mid*100:.1f}%")
    print(f"Middle penalty:                   -{(edge-mid)*100:.1f}pp")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", choices=["medalign", "waymark"],
                        default="waymark")
    parser.add_argument("--data_dir", default="",
                        help="MedAlign data directory (medalign only)")
    parser.add_argument("--notes_csv",
                        default="/Users/sanjaybasu/waymark-local/data/real_inputs/notes/encounter notes.csv",
                        help="Waymark encounter notes CSV")
    parser.add_argument("--model_backend", choices=["local", "api"],
                        default="local")
    parser.add_argument("--model_name",
                        default="mistralai/Mistral-7B-Instruct-v0.2")
    parser.add_argument("--smoke_test", action="store_true",
                        help="Quick 3-position, 3-needle smoke test")
    parser.add_argument("--output_dir",
                        default="/Users/sanjaybasu/waymark-local/notebooks/inhibitory-attention-ehr/figures")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    output_csv = os.path.join(args.output_dir, f"exp1_litm_{args.source}.csv")
    output_fig = os.path.join(args.output_dir, f"exp1_litm_{args.source}.png")

    # Load records
    print(f"Loading {args.source} records...")
    if args.source == "waymark":
        records = load_waymark_notes(args.notes_csv, min_words=200)
        print(f"  Loaded {len(records)} patients with ≥200 words")
    else:
        assert args.data_dir, "--data_dir required for medalign"
        records = load_medalign_records(args.data_dir)
        print(f"  Loaded {len(records)} MedAlign records")

    if not records:
        print("No records loaded. Check data path.")
        return

    # Select needles
    needles = NEEDLE_BANK
    positions = POSITIONS
    n_trials = 3

    if args.smoke_test:
        records = records[:5]
        needles = NEEDLE_BANK[:3]
        positions = [0.1, 0.5, 0.9]
        n_trials = 1
        print("Smoke test mode: 5 records × 3 needles × 3 positions")

    # Set up inference
    if args.model_backend == "api":
        def inference_fn(ctx, q): return query_model_api(ctx, q)
    else:
        # Lazy-load so import errors don't break smoke tests
        _model_loaded = [False]
        _tokenizer = [None]
        _model = [None]

        def inference_fn(ctx, q):
            if not _model_loaded[0]:
                print(f"Loading model {args.model_name}...")
                from transformers import AutoTokenizer, AutoModelForCausalLM
                import torch
                _tokenizer[0] = AutoTokenizer.from_pretrained(args.model_name)
                _model[0] = AutoModelForCausalLM.from_pretrained(
                    args.model_name, device_map="auto",
                    torch_dtype=torch.float16, load_in_4bit=True,
                )
                _model_loaded[0] = True
            return query_model_local(ctx, q, args.model_name)

    # Run
    print(f"\nRunning experiment: {len(records)} records × "
          f"{len(needles)} needles × {len(positions)} positions × {n_trials} trials")
    df = run_experiment(
        records=records,
        needles=needles,
        inference_fn=inference_fn,
        output_csv=output_csv,
        n_trials_per_position=n_trials,
    )

    print_summary(df)
    plot_ucurve(df, output_fig,
                title=f"Lost-in-the-Middle in Clinical EHR ({args.source})")


if __name__ == "__main__":
    main()
