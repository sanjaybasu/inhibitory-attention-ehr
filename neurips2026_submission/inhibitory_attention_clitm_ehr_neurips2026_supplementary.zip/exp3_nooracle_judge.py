"""
No-oracle LLM-as-judge: re-judges v4 responses WITHOUT gold evidence in the prompt.

Addresses reviewer concern that providing gold evidence to the judge biases outcomes.
The oracle-blind judge assesses whether the response provides a specific, direct
clinical answer vs. refusing/hedging — a form of answerability scoring.

Agreement between oracle-judge and no-oracle judge is reported as a robustness check.

Run:
  python exp3_nooracle_judge.py

Input:  figures/exp3_v4_llm_results_judged.csv   (has existing oracle judge scores)
Output: figures/exp3_nooracle_judge_results.csv   (adds *_judge_blind columns)
"""

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import anthropic

FIGURES = Path(__file__).parent.parent / "figures"

# Oracle-blind judge: no gold evidence — evaluates whether the model gave a
# specific, direct clinical answer rather than hedging/refusing.
BLIND_JUDGE_PROMPT = """\
You are a medical expert evaluating whether a clinical AI assistant directly answers a \
clinical question with specific medical information.

Question: {question}
AI response: {response}

Does the AI response directly and specifically answer the question with concrete clinical \
information? Answer YES if it provides a specific answer (a diagnosis, value, medication, \
date, or clear clinical finding). Answer NO if the response says it cannot find \
information, is evasive, gives only generic advice without answering the specific \
question, or explicitly declines.

Answer with exactly one word: YES or NO"""


def judge_blind(client: anthropic.Anthropic, question: str, response: str,
                max_retries: int = 5) -> float:
    if not response or len(response.strip()) < 3:
        return 0.0
    for attempt in range(max_retries):
        try:
            msg = client.messages.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=10,
                messages=[{"role": "user", "content":
                            BLIND_JUDGE_PROMPT.format(question=question,
                                                      response=response)}]
            )
            text = msg.content[0].text.strip().upper()
            if "YES" in text:
                return 1.0
            if "NO" in text:
                return 0.0
            return 0.5
        except Exception as e:
            wait = (2 ** attempt) * 2
            print(f"    API error (attempt {attempt+1}): {e} — retrying in {wait}s")
            time.sleep(wait)
    return float("nan")


def main():
    in_csv  = FIGURES / "exp3_v4_llm_results_judged.csv"
    out_csv = FIGURES / "exp3_nooracle_judge_results.csv"

    df = pd.read_csv(in_csv)
    print(f"Loaded {len(df)} rows from {in_csv.name}")

    arms = ["baseline", "bm25", "bm25_filtered", "dense", "ce", "qccs"]
    resp_cols = {arm: f"{arm}_response" for arm in arms}
    oracle_cols = {arm: f"{arm}_judge" for arm in arms}
    blind_cols  = {arm: f"{arm}_judge_blind" for arm in arms}

    # Resume from partial output
    if out_csv.exists():
        existing = pd.read_csv(out_csv)
        for arm in arms:
            bc = blind_cols[arm]
            if bc in existing.columns:
                df[bc] = existing[bc]
                print(f"  Resumed {bc}: "
                      f"{df[bc].notna().sum()}/{len(df)} already done")
    else:
        for arm in arms:
            df[blind_cols[arm]] = float("nan")

    client = anthropic.Anthropic()
    total_calls = sum(df[blind_cols[arm]].isna().sum() for arm in arms)
    done = 0
    print(f"Calling blind judge for {total_calls} responses...")

    for arm in arms:
        bc = blind_cols[arm]
        rc = resp_cols[arm]
        pending = df[df[bc].isna()].index
        for i in pending:
            q = str(df.at[i, "question"])
            r = str(df.at[i, rc]) if rc in df.columns else ""
            df.at[i, bc] = judge_blind(client, q, r)
            done += 1
            if done % 10 == 0:
                df.to_csv(out_csv, index=False)
                print(f"  {done}/{total_calls}  (checkpoint saved)")

    df.to_csv(out_csv, index=False)
    print(f"\nSaved: {out_csv}")

    # ── Compute agreement statistics ──────────────────────────────────────────
    df["is_mid"] = df["position"].between(0.3, 0.7)
    print("\n=== Oracle vs. Blind Judge Agreement ===")
    for arm in arms:
        oc = oracle_cols[arm]
        bc = blind_cols[arm]
        if oc not in df.columns or bc not in df.columns:
            continue
        valid = df[df[oc].notna() & df[bc].notna()]
        if len(valid) == 0:
            continue
        agree = ((valid[oc] == 1.0) == (valid[bc] == 1.0)).mean()
        oracle_acc = (valid[oc] == 1.0).mean() * 100
        blind_acc  = (valid[bc] == 1.0).mean() * 100
        print(f"  {arm:16s}  oracle={oracle_acc:5.1f}%  blind={blind_acc:5.1f}%  "
              f"agreement={agree*100:.1f}%")

    # ── Summary table ─────────────────────────────────────────────────────────
    print("\n=== Blind Judge: Overall / Middle / Edge ===")
    for label, mask in [("Overall", slice(None)),
                        ("Middle (30-70%)", df["is_mid"]),
                        ("Edge", ~df["is_mid"])]:
        sub = df[mask] if isinstance(mask, pd.Series) else df
        n   = len(sub)
        print(f"\n{label} (N={n}):")
        for arm in arms:
            bc = blind_cols[arm]
            if bc in sub.columns:
                pct = (sub[bc] == 1.0).mean() * 100
                print(f"  {arm}: {pct:.1f}%")

    # ── Bootstrap CIs (overall) ───────────────────────────────────────────────
    np.random.seed(42)
    print("\nBootstrap 95% CIs (overall, 5000 resamples):")
    for arm in arms:
        bc = blind_cols[arm]
        if bc in df.columns:
            vals = (df[bc] == 1.0).astype(float).values
            boots = [np.mean(np.random.choice(vals, len(vals), replace=True))
                     for _ in range(5000)]
            lo, hi = np.percentile(boots, [2.5, 97.5])
            print(f"  {arm}: {vals.mean()*100:.1f}% [{lo*100:.1f}, {hi*100:.1f}]")


if __name__ == "__main__":
    main()
